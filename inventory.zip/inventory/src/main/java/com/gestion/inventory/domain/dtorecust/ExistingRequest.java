package com.gestion.inventory.domain.dtorecust;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExistingRequest {
    Integer stockACtual;
    Integer stockMinimo;
}
